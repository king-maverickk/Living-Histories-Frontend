import ChooseEvent from './ChooseEvent';

export default { ChooseEvent };
