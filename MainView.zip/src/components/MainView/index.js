import React from 'react';
import PropTypes from 'prop-types';
import cn from 'classnames';

function MainView(props) {
  return (
    <div
      className={`main-view flex flex-col h-full relative ${props.className ||
        ''}`}>
      {/* Main section containing user location and podcast readiness */}

      <div className="flex flex-col bg-[rgb(202,212,221)] h-full overflow-hidden relative">
        <div className="flex flex-col overflow-hidden">
          {/* Section for current user location details */}

          <div className="flex flex-col bg-white rounded-[38px] shadow-[0px_4px_51px_0px_rgba(0,0,0,0.1)] overflow-hidden mt-8 mx-3.75 mb-142.5">
            <div className="flex items-center gap-x-3.25 mt-4 mx-6 mb-3.5">
              <img
                className="w-7"
                src={'/assets/MainView/right_arrow.png'}
                alt="alt text"
              />

              <div className="w-52.25 flex flex-col">
                <p className="font-medium text-5 leading-1.2 font-Inter text-black mr-8">
                  Current User Loc
                </p>
                <p className="text-4.5 leading-1.22 font-Inter text-black">
                  Podcast readiness?
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="w-142 h-55 flex gap-x-3 absolute left-3.75 bottom-5.25 min-h-31">
        {/* Section for information related to a specific place */}

        <div className="flex flex-col bg-white rounded-2xl w-69.5 overflow-hidden">
          <div className="flex flex-col gap-y-4.25 mt-7 mr-2 ml-3.5">
            <div className="flex gap-x-2.5">
              <div className="bg-[rgb(220,233,246)] rounded-[20px] w-10 min-h-10" />

              <div className="w-51.5 flex flex-col gap-y-1 mb-0.75">
                {/* Container for basic information related to the place */}
                <p className="font-medium text-4 leading-1.19 font-Roboto text-[rgb(146,188,228)]">
                  Name of Place
                </p>
                <p className="text-3 leading-1.17 font-Roboto text-black opacity-0.2">
                  x m away
                </p>
              </div>
            </div>

            <div className="flex gap-x-1.75 mx-0.5">
              <p className="font-semibold text-3.5 leading-1.17 font-Roboto text-[rgb(191,191,191)] -tracking-0.4 w-55 h-25 my-px">
                {/* Overview of the place from the database */}
                {`Overview: A story of the 2nd Johannesburg Biennale. Some events took place nearby. Let's dive deep!`}
              </p>
              <img
                className="w-4 h-4"
                src={'/assets/MainView/play_button.png'}
                alt="alt text"
              />
            </div>
          </div>
        </div>

        <div className="bg-white rounded-2xl w-69.5 min-h-31" />
      </div>
    </div>
  );
}

MainView.propTypes = {
  className: PropTypes.string
};

export default MainView;
